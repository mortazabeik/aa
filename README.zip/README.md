
  # سایت نمایش شهیدان

  This is a code bundle for سایت نمایش شهیدان. The original project is available at https://www.figma.com/design/zVshoQX9hwMoJ18Zyblxm1/%D8%B3%D8%A7%DB%8C%D8%AA-%D9%86%D9%85%D8%A7%DB%8C%D8%B4-%D8%B4%D9%87%DB%8C%D8%AF%D8%A7%D9%86.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  